main.cpp is the source file that was used during the demonstration.

OpenGL_CodeBlocks.zip file contains a codeblocks project created with the above main.cpp file.
The project includes the necessary OpenGL libraries inside it.
So you should be able to build and run the demo code straightaway if codeblocks is installed in your machine.

OpenGL_VisualStudio.zip file contains a visual studio project created with the above main.cpp file.
The project includes the necessary OpenGL libraries inside it.
So you should be able to build and run the demo code straightaway if visual studio 2010 or above is installed in your machine.

Installing GLUT.ppt file describes how OpenGL applications/projects can be set up from scratch in some IDEs. The .h, .lib, and .dll files are required for this purpose.

If you have a .exe file only, you will need the glut32.dll file to be present in the same directory to execute the .exe file.