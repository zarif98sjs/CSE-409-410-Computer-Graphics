Draw a 4-wheeled robot body with an antenna on it. The antenna points to the current direction of the robot.
Press c to decrease the wheel size of the robot
Press x to increase the wheel size of the robot